
import project_utils as utils

MODEL_NAME = "model.pkl"
#MODE = 'CREATESETS'
MODE = 'TRAIN'
#MODE = 'TRAINMNIST'
#MODE = 'PREDICT'
#MODE = 'CREATESETFORINCEPTION'
ORIGINAL_DATA_PATH = '/home/osboxes/PycharmProjects/ML_final_project/DataBase/FinalDataset'
PROCESSED_DATA_PATH = '/home/osboxes/PycharmProjects/ML_final_project/DataBase/ProcessedDataset'
DATASETS_PATH = "/home/osboxes/PycharmProjects/ML_final_project/DataBase/"
RAW_DATASET_PATH = '/home/osboxes/PycharmProjects/ML_final_project/DataBase/FinalDataset'
TRAIN_SET_PATH = "/home/osboxes/PycharmProjects/ML_final_project/DataBase//Trainset/"
VALIDATE_SET_PATH = "/home/osboxes/PycharmProjects/ML_final_project/DataBase//Validateset"
TEST_SET_PATH = "/home/osboxes/PycharmProjects/ML_final_project/DataBase/Testset/"
WORKSPACE_PATH = "/home/osboxes/PycharmProjects/ML_final_project/Models/"
MODEL_FULL_PATH = "//home/osboxes/Desktop/ML/Final_Project/Models/21.20170125/output_model.pb"
LABELS_FULL_PATH = "/home/osboxes/Desktop/ML/Final_Project/Models/21.20170125/labels.txt"
PREDICT_PATH = "/home/osboxes/Desktop/ML/Final_Project/Datasets/Predictset/"
IMAGE_SIZE = (64,64)



if MODE == 'CREATESETS':
    utils.create_datasets(RAW_DATASET_PATH, DATASETS_PATH, IMAGE_SIZE)
elif MODE == 'CREATESETFORINCEPTION':
    utils.retrain_inception_options()
elif MODE == 'TRAINMNIST':
    utils.train_mnist()
elif MODE == 'TRAIN':
    num_of_classes = -1
    save_model = True
    load_model = True
    trainset_data, trainset_labels, classes = utils.get_dataset(TRAIN_SET_PATH, num_of_classes)
    testset_data, testset_labels, classes = utils.get_dataset(TEST_SET_PATH, num_of_classes)
    validateset_data, validateset_labels, classes = utils.get_dataset(VALIDATE_SET_PATH, num_of_classes)


    trainset_data = utils.prepare_data(trainset_data, IMAGE_SIZE, do_image_to_gray=True, do_scale_image_values=True)
    testset_data = utils.prepare_data(testset_data, IMAGE_SIZE, do_image_to_gray=True, do_scale_image_values=True)
    validateset_data = utils.prepare_data(validateset_data, IMAGE_SIZE, do_image_to_gray=True, do_scale_image_values=True)


    for i in range(100):
        utils.train(trainset_data, trainset_labels, validateset_data, validateset_labels, testset_data, testset_labels, IMAGE_SIZE, len(classes), WORKSPACE_PATH, save_model, load_model)
elif MODE == 'PREDICT':
    #utils.predict_no_labels(PREDICT_PATH, LABELS_FULL_PATH, MODEL_FULL_PATH)
    num_of_classes = -1
    testset_data, testset_labels, classes = utils.get_dataset(TEST_SET_PATH, num_of_classes)

    utils.predict_with_labels(images=testset_data, labels=testset_labels, labelsFullPath=LABELS_FULL_PATH, modelFullPath=MODEL_FULL_PATH, is_inception=False)


